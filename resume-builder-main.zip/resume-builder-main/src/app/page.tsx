"use client";

import Landing from '../components/home/landing';

export default function Home() {
  return <Landing onStart={() => {}} />;
}